<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * Nagaraja Kharvi (nagrgk@gmail.com)
 */
 
namespace Kharvi\LimitedQtyPerCart\Plugin;

use Magento\Framework\Message\ManagerInterface;
use Magento\Checkout\Model\Session;
use Magento\Checkout\Model\Cart;

class LimitedQtyUpdateToCart
{
    /**
     * @var ManagerInterface
     */
    protected $_messageManager;

    /**
     * @var \Magento\Quote\Model\Quote
     */
    protected $_quote;
    
    protected $_helper;

    /**
     * Plugin constructor.
     *
     * @param \Magento\Checkout\Model\Session $checkoutSession
     */
    public function __construct(
        Session $checkoutSession,
        ManagerInterface $messageManager,
        \Kharvi\Limitedqtypercart\Helper\Data $helper
    ) {
        $this->_quote = $checkoutSession->getQuote();
        $this->_messageManager = $messageManager;
        $this->_helper = $helper;
    }

    /**
     * @param \Magento\Checkout\Model\Cart $subject
     * @param $data
     * @return array
     */
    public function beforeupdateItems(Cart $subject,$data)
    {
        $allowedQty = $this->_helper->getStoreConfigValue('kharvi_configurations/general/qty_per_cart');
        if(!empty($allowedQty) && $allowedQty!=''){
            $allColorcodes = array();
            $colorcodes = $this->_helper->getStoreConfigValue('kharvi_configurations/general/vpns');
            if(isset($colorcodes) && $colorcodes!=''){
                $allColorcodes = explode(',', $colorcodes);
            }

            $items = $this->_quote->getAllItems();
            
            foreach($items as $item) {
                $colorcode = $item->getProduct()->getData('color_code');
                $itemId = $item->getItemId();
                if(isset($data[$itemId])){
                    $itemQty= $data[$itemId]['qty'];
                    
                    if($itemQty>$allowedQty && in_array($colorcode, $allColorcodes)){
                        $this->_messageManager->addErrorMessage('\''.$item->getName().'\''.' cannot be ordered in requested quantity.');
                        $data[$itemId]['qty']=$item->getQty();
                    }
                }
            }
        }
       
        return [$data];
    }
}