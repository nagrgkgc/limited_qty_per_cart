<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * Nagaraja Kharvi (nagrgk@gmail.com)
 */

namespace Kharvi\LimitedQtyPerCart\Plugin;

use Magento\Checkout\Model\Cart;

class LimitedQtyAddToCart
{
    /**
     * @var \Magento\Quote\Model\Quote
     */
    protected $_quote;
    protected $_helper;
    protected $_productLoader;
    
    /**
     * Plugin constructor.
     *
     * @param \Magento\Checkout\Model\Session $checkoutSession
     */
    public function __construct(
        \Magento\Checkout\Model\Session $checkoutSession,
        \Kharvi\Limitedqtypercart\Helper\Data $helper,
        \Magento\Catalog\Model\ProductFactory $productLoader
    ) {
        $this->_quote = $checkoutSession->getQuote();
        $this->_helper = $helper;
        $this->_productLoader = $productLoader;
    }
    
    public function beforeAddProduct(Cart $subject, $productInfo, $requestInfo = null)
    {
        //get allowed qty's
        $allowedQty = $this->_helper->getStoreConfigValue('kharvi_configurations/general/qty_per_cart');
        
        if(!empty($allowedQty) && $allowedQty!=''){
            $allColorcodes = array();
            $colorcodes = $this->_helper->getStoreConfigValue('kharvi_configurations/general/color_codes');
            if(isset($colorcodes) && $colorcodes!=''){
                $allColorcodes = explode(',', $colorcodes);
            }
            
            //check product type
            $typeId = $productInfo->getTypeId();
            $product = $productInfo;
            if($typeId == 'configurable'){
                $newProductId = (int)$requestInfo['selected_configurable_option'];
                $product = $this->_productLoader->create()->load($newProductId);
            }
            
            //get current product primary vpn
            $colorcode = $product->getColorCode();
            
            //get cart quote items
            $items = $this->_quote->getAllItems();
       
            //initialize variables
            $name='';$itemCount=0;
            
            //current requested qty
            $qty = (isset($requestInfo['qty']))? $requestInfo['qty'] : 1;
            $name = $product->getName();
            
            foreach($items as $item) {
                $primaryColorcode = $item->getProduct()->getData('color_code');
                
                if(!empty($primaryColorcode) && $primaryColorcode!='' && $colorcode == $primaryColorcode){
                    $itemCount += $item->getQty();
                }
            }
            
            $totalRequestdQty = $itemCount + $qty;
            if($totalRequestdQty > $allowedQty  && in_array($colorcode, $allColorcodes)){
                throw new \Magento\Framework\Exception\LocalizedException(__("'".$name . "'" . " cannot be ordered in requested quantity."));
            }
        }
        
        return [$productInfo,$requestInfo];
    }
}