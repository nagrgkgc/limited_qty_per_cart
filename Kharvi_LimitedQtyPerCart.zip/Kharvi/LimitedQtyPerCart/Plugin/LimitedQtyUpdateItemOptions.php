<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * Nagaraja Kharvi (nagrgk@gmail.com)
 */
 
namespace Kharvi\LimitedQtyPerCart\Plugin;

use Magento\Framework\Message\ManagerInterface;
use Magento\Checkout\Model\Session;
use Magento\Checkout\Model\Cart;

class LimitedQtyUpdateItemOptions
{
    /**
     * @var ManagerInterface
     */
    protected $_messageManager;

    /**
     * @var \Magento\Quote\Model\Quote
     */
    protected $_quote;
    protected $_helper;
    protected $_productLoader;

    /**
     * Plugin constructor.
     *
     * @param \Magento\Checkout\Model\Session $checkoutSession
     */
    public function __construct(
        ManagerInterface $messageManager,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Kharvi\Limitedqtypercart\Helper\Data $helper,
        \Magento\Catalog\Model\ProductFactory $productLoader
    ) {
        $this->_quote = $checkoutSession->getQuote();
        $this->_messageManager = $messageManager;
        $this->_helper = $helper;
        $this->_productLoader = $productLoader;
    }

    public function beforeupdateItem(Cart $subject, $itemId, $requestInfo = null)
    {
        $allowedQty = $this->_helper->getStoreConfigValue('kharvi_configurations/general/qty_per_cart');
        
        if(!empty($allowedQty) && $allowedQty!=''){
            $allColorcodes = array();
            $colorcodes = $this->_helper->getStoreConfigValue('kharvi_configurations/general/color_codes');
            if(isset($colorcodes) && $colorcodes!=''){
                $allColorcodes = explode(',', $colorcodes);
            }
            
            $item = $this->_quote->getItemById($itemId);
            $productId = $item->getProduct()->getId();
            if ($productId) {
                $newProductId = $requestInfo->getProduct();
                $itemQty= $requestInfo->getQty();
                
                if(!$this->_quote->hasProductId($newProductId)){
                    $items = $this->_quote->getAllItems();
                    $productInfo = $this->_productLoader->create()->load($newProductId);
                    $colorcode = $productInfo->getColorCode();
                    foreach($items as $item) {
                        $primaryColorcode = $item->getProduct()->getData('color_code');
                        
                        //qty data
                        $qty = (isset($itemQty))? $itemQty : 1;
                        $requestdQty = $itemQty;
                        
                        if($colorcode == $primaryColorcode && $requestdQty > $allowedQty){
                            break;
                        }
                    }
                
                    if($colorcode == $primaryColorcode && in_array($colorcode, $allColorcodes) && $requestdQty > $allowedQty){
                        throw new \Magento\Framework\Exception\LocalizedException(__('\''.$item->getName().'\''.' cannot be ordered in requested quantity.'));
                    }
                }else{
                    $colorcode = $item->getProduct()->getData('color_code');
                    if($itemQty>$allowedQty && in_array($colorcode, $allColorcodes)){
                        throw new \Magento\Framework\Exception\LocalizedException(__('\''.$item->getName().'\''.' cannot be ordered in requested quantity.'));
                    }
                }
            }
        }
        
        return [$itemId,$requestInfo];
    }
}